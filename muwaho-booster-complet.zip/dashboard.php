<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';
require_login();
echo "<h2>Bienvenue sur votre tableau de bord</h2>";
?>
<a href='commande.php'>Passer une commande</a><br>
<a href='recharge.php'>Recharger</a>
