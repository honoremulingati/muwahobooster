<?php
function call_exobooster_api($endpoint, $postData) {
    $apiKey = '8d7952c84ed083248f9b1ab40ab63827';
    $postData['key'] = $apiKey;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://exosupplier.com/api/v2/$endpoint");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        return ['error' => curl_error($ch)];
    }
    curl_close($ch);
    return json_decode($response, true);
}
?>