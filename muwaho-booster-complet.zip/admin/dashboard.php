<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_admin();
echo "<h2>Dashboard Admin</h2>";
?>
<ul>
    <li><a href="#">Voir les commandes</a></li>
    <li><a href="#">Voir les utilisateurs</a></li>
</ul>
