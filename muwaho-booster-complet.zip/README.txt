Fichier de démarrage MUWAHOBOOSTER.
- Importez le SQL dans phpMyAdmin.
- Configurez includes/db.php
- Utilisez admin/adminpass pour l’espace admin.
